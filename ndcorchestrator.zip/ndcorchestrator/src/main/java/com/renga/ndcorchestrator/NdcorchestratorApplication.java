package com.renga.ndcorchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NdcorchestratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(NdcorchestratorApplication.class, args);
	}

}
